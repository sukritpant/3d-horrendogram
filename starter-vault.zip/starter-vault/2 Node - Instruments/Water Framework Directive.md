---
type: instrument
level: eu
tags:
  - legislation
  - water
---

## Description

Example instrument. EU directive setting the framework for protecting inland, coastal and ground waters.
