---
type: instrument
level: national
tags:
  - legislation
  - water
---

## Description

Example instrument. National law that transposes the Water Framework Directive.
