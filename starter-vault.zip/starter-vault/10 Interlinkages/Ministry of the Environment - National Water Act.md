---
type: interlinkage
from: "[[Ministry of the Environment]]"
to: "[[National Water Act]]"
tags:
  - governance
---

## Description

The ministry prepares amendments to the act and steers its implementation.
