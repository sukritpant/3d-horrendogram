---
type: interlinkage
from: "[[European Commission]]"
to: "[[Water Framework Directive]]"
tags:
  - governance
---

## Description

The Commission proposed the directive and monitors its implementation in member states.
