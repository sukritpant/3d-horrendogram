---
type: interlinkage
from: "[[Water Framework Directive]]"
to: "[[National Water Act]]"
tags:
  - water
---

## Description

The National Water Act transposes the directive into national law.
