---
type: interlinkage
from: "[[SOURCE NODE NAME]]"
to: "[[TARGET NODE NAME]]"
tags:
  - governance
---

## Description

Write 2–6 sentences explaining how the source and target are related and what
the relationship means in practice.
