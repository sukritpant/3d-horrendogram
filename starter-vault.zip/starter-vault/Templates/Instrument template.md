---
type: instrument
level: national
tags:
  - legislation
---

## Description

Write 2–4 sentences describing what this instrument is and what it regulates.
