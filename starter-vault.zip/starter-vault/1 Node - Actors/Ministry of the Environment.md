---
type: actor
level: national
tags:
  - governance
---

## Description

Example actor. The national ministry responsible for environmental policy and for preparing environmental legislation.
