---
type: actor
level: eu
tags:
  - governance
---

## Description

Example actor. The EU's executive body; it proposes EU legislation and monitors how member states implement it. More at [the Commission's website](https://commission.europa.eu).
